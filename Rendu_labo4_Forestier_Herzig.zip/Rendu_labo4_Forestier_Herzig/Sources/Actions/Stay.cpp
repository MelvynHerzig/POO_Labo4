#include "Stay.h"

void Stay::execute(Field& f)
{
   // Ne fait rien
   // L'entité doit rester sur place
}
